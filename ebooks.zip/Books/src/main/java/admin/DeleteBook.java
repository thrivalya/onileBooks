package admin;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import connections.DBConnect;
@WebServlet("/deleteBook")
public class DeleteBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BookVarables var = new BookVarables();
		Connection connection = null;
		connection = DBConnect.getConn();
		int id=Integer.parseInt(request.getParameter("id"));
		String sql="delete from book_details where id=?;";
        HttpSession session = request.getSession();

		try {
			PreparedStatement pst=connection.prepareStatement(sql);
			pst.setInt(1, id);
			int rows1=0;
		    rows1=pst.executeUpdate();
			if(rows1>0) {
				request.setAttribute("Dstatus", "success");

			}
				
			else {
				request.setAttribute("Dstatus", "failed");

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("Dstatus", "failed");

		}
	   
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("admin.jsp");
        dispatcher.forward(request, response);
		} 
	}



