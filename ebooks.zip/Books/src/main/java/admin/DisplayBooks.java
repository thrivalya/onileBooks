package admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import connections.DBConnect;

public class DisplayBooks {
	public List<BookVarables> getAllBooks(){
		List<BookVarables> list=new ArrayList<BookVarables>();
		BookVarables b = null;
		Connection connection = null;
		connection = DBConnect.getConn();
		String query="select * from book_details;";
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				b=new BookVarables();
				b.setId(rs.getInt(1));
				b.setBname(rs.getString(2));
				b.setAuthor(rs.getString(3));
				b.setCat(rs.getString(5));
				b.setDec(rs.getString(6));
				b.setPhoto(rs.getString(7));
				b.setPrice(rs.getString(4));
				b.setQua(rs.getString(8));
				list.add(b);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
	public BookVarables getBookById(int id) {
		BookVarables b = null;
		Connection connection = null;
		connection = DBConnect.getConn();
		String query="select * from book_details where id=?;";
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				b=new BookVarables();
				b.setId(rs.getInt(1));
				b.setBname(rs.getString(2));
				b.setAuthor(rs.getString(3));
				b.setCat(rs.getString(5));
				b.setDec(rs.getString(6));
				b.setPhoto(rs.getString(7));
				b.setPrice(rs.getString(4));
				b.setQua(rs.getString(8));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
		
	}

}
