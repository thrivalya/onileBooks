package admin;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import connections.DBConnect;

@WebServlet("/editBooks")   

public class EditBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BookVarables var = new BookVarables();
		int id=Integer.parseInt(request.getParameter("id"));
		var.setId(id);

		var.setBname( request.getParameter("bname"));
		var.setPhoto(request.getParameter("photo"));
		var.setAuthor( request.getParameter("author"));
		var.setPrice( request.getParameter("price"));
		var.setQua(request.getParameter("quantity"));
		var.setCat(request.getParameter("catagory"));
		var.setDec(request.getParameter("dec"));
        HttpSession session = request.getSession();


		PrintWriter out=response.getWriter();
		Connection connection = null;
        // Call the getConn method from DBConnect to get the connection
		connection = DBConnect.getConn();
		String query="update book_details set name=?, author=?, price=?, category=?, description=?, photo=?, quantity=? where id=?;";
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(query);
			
			pst.setString(1, var.getBname());
			pst.setString(2, var.getAuthor());
			pst.setString(3, var.getPrice());
			pst.setString(4, var.getCat());
			pst.setString(5, var.getDec());
			pst.setString(6, var.getPhoto());
			pst.setString(7, var.getQua());
			pst.setInt(8, var.getId());

			int rows1=0;
		    rows1=pst.executeUpdate();
			if(rows1>0) {
				request.setAttribute("Estatus", "success");

			}
				
			else {
				request.setAttribute("Estatus", "failed");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("Estatus", "failed");


		}
	   
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("editBook.jsp");
        dispatcher.forward(request, response);
	}
}

