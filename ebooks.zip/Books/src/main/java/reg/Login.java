package reg;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import connections.DBConnect;

public class Login {
	public Varables login(String name,String password) {
		Varables o=null;
		Connection connection = DBConnect.getConn();

		try {
		String sql="SELECT * FROM registration WHERE username=? AND password=?";
		PreparedStatement ps=connection.prepareStatement(sql);
		ps.setString(1, name);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			o=new Varables();
			o.setUid(rs.getInt(1));
			o.setName(rs.getString(2));
			o.setPassword(rs.getString(3));
			o.setAddress(rs.getString(4));
			o.setPin(rs.getString(5));
			
			
		}
		}
		catch (Exception e) {
e.printStackTrace();
}
		
		return o;
		
	}
}
