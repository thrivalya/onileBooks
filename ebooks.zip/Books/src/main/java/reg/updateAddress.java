package reg;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import admin.BookVarables;
import connections.DBConnect;

@WebServlet("/Aupdate")
public class updateAddress extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Varables var = new Varables();
		int id=Integer.parseInt(request.getParameter("uid"));
		var.setUid(id);
		var.setAddress(request.getParameter("address"));
		var.setPin(request.getParameter("pincode"));
		
        HttpSession session = request.getSession();


		PrintWriter out=response.getWriter();
		Connection connection = null;
        // Call the getConn method from DBConnect to get the connection
		connection = DBConnect.getConn();
		out.print(connection);
		String query="update registration set address=?, pin=? where sno=?;";
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(query);
			
			pst.setString(1, var.getAddress());
			pst.setString(2, var.getPin());
			pst.setInt(3,id );


			int rows1=0;
		    rows1=pst.executeUpdate();
			if(rows1>0) {
				request.setAttribute("Ustatus", "success");

			}
				
			else {

				request.setAttribute("Ustatus", "failed");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("Ustatus", "failed");


		}
	   
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("allbooks.jsp");
        dispatcher.forward(request, response);
	}

}
