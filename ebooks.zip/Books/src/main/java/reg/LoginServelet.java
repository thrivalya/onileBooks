package reg;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import connections.DBConnect;

@WebServlet("/login")
public class LoginServelet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection connection = null;
        PrintWriter out = response.getWriter();
        String Ename = request.getParameter("name");
        String Epass = request.getParameter("password");
        Login obj=new Login();
        HttpSession session=request.getSession();
        // Call the getConn method from DBConnect to get the connection
        connection = DBConnect.getConn();
        RequestDispatcher dispatcher = null;
        try {
        	if("admin".equals(Ename)&&"admin".equals(Epass)) {
            	response.sendRedirect("admin.jsp");
            }
        	else {
        		Varables o=obj.login(Ename, Epass);
        		if(o!=null) {
        			// Login successful
                    request.setAttribute("status", "success");
                    session.setAttribute("userobj", o);;
                } else {
                    // Login failed
                    request.setAttribute("status", "failed");
                }
                
                dispatcher = request.getRequestDispatcher("loginStatus.jsp");
                dispatcher.forward(request, response);
        		
        	}
        }
        catch (Exception e) {
        e.printStackTrace();
        }

    }

}
