package cart;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import admin.BookVarables;
import connections.DBConnect;

public class DisplayCart {
	Connection connection = DBConnect.getConn();

	public boolean addCart(CartVarables c) {
		boolean f=false;
		try {
			String query="INSERT INTO `ebook`.`cart_table` (`bid`, `uid`, `bookName`, `price`, `totalPrice`, `img`) VALUES (?,?,?,?,?,?);";
			PreparedStatement ps=connection.prepareStatement(query);
			ps.setInt(1, c.getBid());
			ps.setInt(2, c.getUid());
			ps.setString(3, c.getBname());
			ps.setDouble(4, c.getPrice());
			ps.setDouble(5, c.getTotalprice());
			ps.setString(6, c.getImg());

			int i=ps.executeUpdate();
			if(i==1) {
				f=true;
			}
		}
		catch (Exception e) {
		e.printStackTrace();
		}	
		
		return f;
	}
	public List<CartVarables> getBookByUser(int userid){
		List<CartVarables> list=new ArrayList<CartVarables>();
		CartVarables c=null;
		double totalPrice=0;
		try {
			String sql="select * from cart_table where uid=?";
			PreparedStatement ps=connection.prepareStatement(sql);
			ps.setInt(1, userid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				c=new CartVarables();
				c.setCid(rs.getInt(1));
				c.setBid(rs.getInt(2));
				c.setUid(rs.getInt(3));
				c.setBname(rs.getString(4));
				c.setPrice(rs.getDouble(5));
				totalPrice=totalPrice+rs.getDouble(6);
				c.setTotalprice(totalPrice);
				
				c.setImg(rs.getString(7));
				list.add(c);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return list;
		
		
	}
	public boolean deleteBook(int bid,int uid) {
		boolean f=false;
		
		try {
			String sql="delete from cart_table where bid=? and uid=?";
			PreparedStatement ps=connection.prepareStatement(sql);
			ps.setInt(1,bid);
			ps.setInt(2,uid);

			int i=ps.executeUpdate();
			if(i==1) {
				f=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return f;
		
	}
}
