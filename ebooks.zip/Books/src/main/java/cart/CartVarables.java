package cart;

public class CartVarables {
	private int cid;
	private int bid;
	private int uid;
	private String bname;
private double price;
private double Totalprice;
private String img;


public String getImg() {
	return img;
}
public void setImg(String img) {
	this.img = img;
}
public String getBname() {
	return bname;
}
public void setBname(String bname) {
	this.bname = bname;
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public int getBid() {
	return bid;
}
public void setBid(int bid) {
	this.bid = bid;
}
public int getUid() {
	return uid;
}
public void setUid(int uid) {
	this.uid = uid;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public double getTotalprice() {
	return Totalprice;
}
public void setTotalprice(double totalprice) {
	Totalprice = totalprice;
}

	
}
