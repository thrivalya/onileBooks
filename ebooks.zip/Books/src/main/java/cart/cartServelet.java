package cart;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import admin.BookVarables;
import admin.DisplayBooks;
import connections.DBConnect;

@WebServlet("/cart")
public class cartServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			int bid=Integer.parseInt(req.getParameter("bid"));
			int uid=Integer.parseInt(req.getParameter("uid"));
			
			CartVarables c=new CartVarables();
			 DisplayBooks o=new DisplayBooks();
		     BookVarables b=o.getBookById(bid);
			c.setBid(bid);
			c.setUid(uid);
			c.setBname(b.getBname());
			c.setPrice(Double.parseDouble(b.getPrice()));
			c.setTotalprice(Double.parseDouble(b.getPrice()));
			c.setImg(b.getPhoto());
			DisplayCart obj=new DisplayCart();
			boolean f=obj.addCart(c);
			HttpSession session=req.getSession();
			if(f) {
				req.setAttribute("Cartstatus", "success");

			}
			else {

				req.setAttribute("Cartstatus", "failed");
			}
			RequestDispatcher dispatcher = req.getRequestDispatcher("allbooks.jsp");
	        dispatcher.forward(req, resp);
		}
		catch (Exception e) {
			System.out.println("something wrong in sql");

		e.printStackTrace();
		}
	}
	

}
